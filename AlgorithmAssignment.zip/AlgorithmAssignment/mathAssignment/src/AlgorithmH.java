public class AlgorithmH {
    public static float run(int[] s, float idealSum){
        //This goes through all 2-way partitions, and outputs the lowest deviation from the ideal partition.
        //This program uses binary to represent every possible partition. 1 means the element is added to s1,
        //0 means the element is added to s2.
        //e.g.  [1,2,3]
        //All possible partitions.

        //000   s1={}       s2={1,2,3}
        //001   s1={3}      s2={1,2}
        //010   s1={2}      s2={1,3}
        //011   s1={2,3}    s2={1}
        //100   s1={1}      s2={2,3}
        //101   s1={1,3}    s2={2}
        //110   s1={1,2}    s2={3}
        //111   s1={1,2,3}  s2={}

        //This shows that by using binary numbers, it is possible to represent all possible partitions of S.

        //This will store the current best deviation from the ideal partition

        //the Math.abs bit makes the ideal sum a positive number. If the ideal sum was <0, then
        // (int)idealSum would convert it to 0, so to prevent the program from multiplying the deviation by 0,
        //the program adds 2 to the deviation value. The program then multiplies the deviation by 3 to get
        //an upper bound for the deviation from the ideal partition. This will output a value that has
        // a non-zero value that is bigger than the biggest deviation that is possible to get.


        float currentDeviationFromIdeal = (Math.abs((int)idealSum) +2)  * 3;

        //this will create an array containing the powers of 2, between 2^1, and 2^number of items in the array
        //this will represent each binary digit in an N bit binary number, where N=number of items in the array
        int[] BINARY_DIGITS = new int[s.length];
        for (int index = 0; index < s.length; index++){
            BINARY_DIGITS[index]=(int) Math.pow(2, index);
        }

        for (long partitionNumber = 0; partitionNumber < Math.pow(2,s.length - 1); partitionNumber++){
            //this goes through half of all possible binary combinations of numbers. It only goes
            //through half of them because the other half just swaps S1 with S2, which has the same
            //deviation from the ideal partition. e.g. 100, and 011 will have the same deviation values.

            int sumS1 = 0, sumS2 = 0;

            //This goes through each digit in the binary number.
            for (int index = 0; index < s.length; index++){

                //Here, the program does a binary AND operation on the current partition number and one of
                //the binary digits in the binary number. This tells the program if the binary digit is
                // a 1 or a 0, and hence whether to add the result to S1 or S2.
                //This will repeat for all the binary digits in the binary number.

                if((partitionNumber & BINARY_DIGITS[index]) == BINARY_DIGITS[index]){
                    sumS1 += s[index];
                } else {
                    sumS2 += s[index];
                }
            }

            //If the current deviation from the ideal partition is better the previous best deviation from
            // the ideal partition, update the current value.
            if (Math.abs(idealSum-sumS1) < currentDeviationFromIdeal){
                currentDeviationFromIdeal = Math.abs(idealSum - sumS1);
                if (currentDeviationFromIdeal == 0){
                    // The program will have split a multiset into 2 equal partitions, if the deviation from the
                    //ideal partition is 0. In that situation, the program will stop searching and will return 0.

                    //This program makes the assumption that as the number of items in the multiset S increases,
                    //the probability of a set existing that splits the multiset S into two equal sums also
                    //increases.
                    break;
                }
            }
        }

        //Finally return the best deviation from the ideal
        return currentDeviationFromIdeal;
    }
}
