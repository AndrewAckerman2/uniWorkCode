import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;


public class Main {
    static final int NUM_INTERATIONS=1000;
    static final int[] ARRAY_SIZE={8,16,32,64,128,256,512,1024};
    static final String[] ALGORITHM_NAMES={"A","B","C","D","E","F","G","H","I"};

    //The value below is the maximum array size that H can run without taking forever.
    static final int ALGORITHM_H_SIZE_LIMIT=16;
    public static void main(String[] args) {
        testingAlgorithms();
        testHarness();

    }



    public static void swap(int[] s,int leftIndex,int rightIndex){
        //this swaps the items at the left and right half
        int tempItem = s[leftIndex];
        s[leftIndex] = s[rightIndex];
        s[rightIndex] = tempItem;

    }
    public static int swap(int[] s,int leftIndex,int rightIndex,int pivotIndex){
        //this swaps the items at the left and right half;
        int tempItem = s[leftIndex];
        s[leftIndex] = s[rightIndex];
        s[rightIndex] = tempItem;

        //The program passed the pivotIndex to deal with duplicate pivots.
        if( leftIndex == pivotIndex){
            //If the pivotIndex equals the left index, that means that the new index position
            //for the pivot will be at the swapped location, at the right index position.
            pivotIndex = rightIndex;
        } else if (rightIndex == pivotIndex) {
            //And vice versa.
            pivotIndex = leftIndex;
        }
        //finally, return the pivot Index.
        return pivotIndex;

    }

    public static void ascendingBruteForceSort(int[] s, int leftIndex, int rightIndex){
        //This sorts a list of 3 items manually in ascending order.
        //This calculates the middle index to represent the central item.
        int middleIndex = leftIndex + 1;
        if(s[rightIndex] < s[leftIndex]){
            if (s[rightIndex] > s[middleIndex]){
                // order is middle, right, left
                swap(s,leftIndex,middleIndex);
                swap(s,middleIndex,rightIndex);
            } else if (s[middleIndex] > s[leftIndex]){
                //if so order is right left middle
                swap(s,leftIndex,rightIndex);
                swap(s,middleIndex,rightIndex);

            } else {
                //if so, order is right middle left
                swap(s,leftIndex,rightIndex);
            }
        } else {
            //if left==right, then it would go here.
            if (s[leftIndex] > s[middleIndex]){
                swap(s,leftIndex,middleIndex);
                //So order is middle, left, right
            } else if (s[middleIndex] > s[rightIndex]){
                //if so order is left right middle
                swap(s,middleIndex,rightIndex);
            }
            //the final possible ordering is if they are in order. In that case, do nothing
        }

    }
    public static void descendingBruteForceSort(int[] s, int leftIndex, int rightIndex){
        //this sorts an array of 3 items into descending order
        //This calculates the middle index to represent the central item.
        int middleIndex = leftIndex + 1;
        if(s[leftIndex] > s[middleIndex]){
            if (s[middleIndex] > s[rightIndex]){
                //So order is left,middle,right so don't do anything
            } else if (s[rightIndex] > s[leftIndex]){
                //order is right left middle
                swap(s, leftIndex, rightIndex);
                swap(s, middleIndex, rightIndex);
            } else {
                //if so, order is left right middle
                swap(s, middleIndex, rightIndex);
            }
        } else {
            //if left==right, then it would go here.
            if (s[leftIndex] > s[rightIndex]){
                //So order is middle, left, right
                swap(s, leftIndex, middleIndex);
                //So order is middle, left, right
            } else if (s[rightIndex] > s[middleIndex]){
                //if so order is right,middle, left
                swap(s, leftIndex, rightIndex);
            } else {
                //middle right left
                swap(s, leftIndex, middleIndex);
                swap(s, middleIndex, rightIndex);
            }

        }

    }


    public static void ascendingQuickSort(int[] s, int leftIndex, int rightIndex){
        //This is quick sort.

        //This calculates their partition length. The + 1 is there to prevent off by 1 error.
        int partitionLen = 1 + rightIndex - leftIndex;

        //These define the left and right half index length side things.
        int LEFT_BOUNDARY = leftIndex;
        int RIGHT_BOUNDARY = rightIndex;

        //Switch operations jump directly to the memory address, which counts as one operation.
        switch (partitionLen){
            case 0:
                //Nothing should occur when the array's length is 0 or 1. To take advantage of the
                //switch counts as one operation, then this shouldn't be in the default section of the code,
                //Which is why the program has Case 0,1: even though they have no code in them
                break;
            case 1:
                break;
            case 2:
                //Swap the left and right element in the array if the array has two items and the
                //left element is bigger than the right element
                if(s[rightIndex] < s[leftIndex]){
                    swap(s,leftIndex,rightIndex);
                }
                break;
            case 3:
                //This program sorts a list of size three using brute force.
                ascendingBruteForceSort(s, leftIndex, rightIndex);
                break;
            default:
                //If the partition size exceeds 3, apply the quick sort algorithm instead of brute force.

                //this gets the median value to act as the pivot point
                int pivotIndex = (int) Math.floor((double) (leftIndex + rightIndex) / 2.0);

                //this is to tell the computer to stop iterating though
                boolean leftSwap = false, rightSwap = false;

                while (leftIndex != rightIndex){
                    //while the index isn't at the same place.

                    if(s[leftIndex] > s[pivotIndex] || leftIndex == pivotIndex){
                        //if the item in the left half is greater than the pivot, then prepare it for swapping
                        leftSwap = true;
                        //if the item in the left half is greater than the pivot, then prepare it for swapping
                    } else {
                        //otherwise, increment it by 1
                        leftIndex++;
                    }

                    if(s[rightIndex] < s[pivotIndex] || rightIndex == pivotIndex){
                        //if the element in the right half is less than the pivot, prepare it for swapping.
                        rightSwap = true;
                    } else {
                        //otherwise, move the right index by 1
                        rightIndex--;
                    }

                    //If both the left and right sides have an item to swap, swap them
                    if(rightSwap && leftSwap){
                        pivotIndex = swap(s, leftIndex, rightIndex, pivotIndex);

                        //Then reset the variables to allow the program to execute again
                        rightSwap = false;
                        leftSwap = false;
                    }
                }
                //Finally, apply the quick sort algorithm to the left and right partitions.
                ascendingQuickSort(s, LEFT_BOUNDARY, pivotIndex - 1);
                ascendingQuickSort(s, pivotIndex + 1, RIGHT_BOUNDARY);

                break;
        }
    }
    public static void descendingQuickSort(int[] s, int leftIndex, int rightIndex){
        //this is quick sort

        //This calculates their partition length. The +1 is there to prevent off by 1 errors
        int partitionLen = 1 + rightIndex - leftIndex;

        //These define the left and right half-index length side things.
        int LEFT_BOUNDARY = leftIndex;
        int RIGHT_BOUNDARY = rightIndex;

        //Switch operations jump directly to the memory address, which counts as one operation.
        switch (partitionLen){
            case 0:
                //Nothing should occur when the array's length is 0 or 1. To take advantage of the
                //switch counts as one operation, then this shouldn't be in the default section of the code,
                //Which is why the program has Case 0,1: even though they have no code in them
                break;
            case 1:
                break;
            case 2:
                //Swap the left and right element in the array if the array has two items and the
                //left element is smaller than the right element
                if(s[rightIndex] > s[leftIndex]){
                    swap(s,leftIndex,rightIndex);
                }
                break;
            case 3:
                //This program sorts a list of size three using brute force.
                descendingBruteForceSort(s,leftIndex,rightIndex);
                break;
            default:
                //if the partition size exceeds 3, apply the quick sort algorithm instead of brute force.

                //this gets the median value to act as the pivot point
                int pivotIndex = (int) Math.floor((double) (leftIndex + rightIndex) / 2.0);

                //this is to tell the computer to stop iterating though
                boolean leftSwap = false, rightSwap = false;

                while (leftIndex != rightIndex){
                    //while the index isn't at the same place.
                    if(s[leftIndex] < s[pivotIndex] || leftIndex == pivotIndex){
                        //if the item in the left half is less than the pivot, then prepare it for swapping
                        leftSwap = true;
                    } else {
                        //otherwise, increment it by 1
                        leftIndex++;
                    }

                    if(s[rightIndex] > s[pivotIndex] || rightIndex == pivotIndex){
                        //If the item in the right half is bigger than the pivot, prepare it for swapping.
                        rightSwap = true;
                    } else {
                        //otherwise, move the right index by 1
                        rightIndex--;
                    }

                    //if both the left and right sides have an item to swap, swap them
                    if(rightSwap && leftSwap){
                        pivotIndex = swap(s, leftIndex, rightIndex, pivotIndex);

                        //Then reset the variables to allow the program to execute again
                        rightSwap = false;
                        leftSwap = false;
                    }
                }
                //Finally, apply the quick sort algorithm to the left and right partitions.
                descendingQuickSort(s, LEFT_BOUNDARY,pivotIndex - 1);
                descendingQuickSort(s,pivotIndex + 1, RIGHT_BOUNDARY);

                break;
        }
    }

    public static float calcIdealSum(int[] s){
        //this calculates the ideal sum and the returns it
        float idealSum = 0f;
        for (int element : s){
            idealSum += element;
        }
        idealSum /= 2;

        return idealSum;
    }

    public static void testingAlgorithms(){
        //This is for documenting the testing stage in step 3.
        int[] sA= {148,712,368,767,179,698,486,407};
        float idealSumA = calcIdealSum(sA);

        System.out.println("The deviation from the ideal sum for algorithm A" +
                " is "+AlgorithmA.run(sA, idealSumA));
        System.out.println("The deviation from the ideal sum for algorithm B" +
                " is "+AlgorithmB.run(sA, idealSumA));
        System.out.println("The deviation from the ideal sum for algorithm C" +
                " is "+AlgorithmC.run(sA, idealSumA));
        System.out.println("The deviation from the ideal sum for algorithm D" +
                " is "+AlgorithmD.run(sA, idealSumA));
        //creating a clone of sA to get around the pass-by-reference limit.
        int[] cloneSA1=sA.clone();
        System.out.println("The deviation from the ideal sum for algorithm E" +
                " is "+AlgorithmE.run(cloneSA1, idealSumA));
        cloneSA1=sA.clone();
        System.out.println("The deviation from the ideal sum for algorithm F" +
                " is "+AlgorithmF.run(cloneSA1, idealSumA));
        cloneSA1=sA.clone();
        System.out.println("The deviation from the ideal sum for algorithm G" +
                " is "+AlgorithmG.run(cloneSA1, idealSumA));

        //a smaller array is created to test algorithm H, as manually creating
        //all combinations out to show evidence of testing an algorithm are
        //difficult for large sizes of n.
        int[] sB={101, 256, 141};
        float idealSumB = calcIdealSum(sB);

        System.out.println("The deviation from the ideal sum for algorithm H" +
                " is "+AlgorithmH.run(sB, idealSumB));

        cloneSA1=sA.clone();
        System.out.println("The deviation from the ideal sum for algorithm I" +
                " is "+AlgorithmI.run(cloneSA1, idealSumA));
    }
    public static void testHarness(){
        //this will automatically test and record results
        //arraySize, array algorithm,
        //this is effectively a table on the x-axis is the Algorithm used, the y-axis is the
        //partition size and each cell stores an ArrayList of values (the output of each algorithm).

        //this creates a table where the program can store my data.
        Table results=new Table(ARRAY_SIZE,ALGORITHM_NAMES);

        //if NUM_INTERATIONS equals 1000, then the program will record 1000 results.
        for(int iteration = 0; iteration < NUM_INTERATIONS; iteration++){
            //loop equal to the number of iterations

            for(int size: ARRAY_SIZE){
                //loop equal to the number of iterations
                int[] s = generateS(size);

                //This finds the ideal sum of a partition.
                float idealSum = calcIdealSum(s);

                for (int currentAlgorithm = 0; currentAlgorithm < ALGORITHM_NAMES.length; currentAlgorithm++){

                    //S is cloned, so tempS points to a different reference. This means each
                    // algorithm will have the same test data, making the test fairer.
                    int[] tempS = s.clone();

                    //this stores the deviation from the ideal partition
                    float deviationFromIdeal = 0;

                    //This executes each algorithm once with the same input data.
                    switch (currentAlgorithm){
                        case 0:
                            //algorithm A.
                            deviationFromIdeal = AlgorithmA.run(tempS,idealSum);
                            break;
                        case 1:
                            //algorithm B.
                            deviationFromIdeal = AlgorithmB.run(tempS,idealSum);
                            break;
                        case 2:
                            //algorithm C.
                            deviationFromIdeal = AlgorithmC.run(tempS,idealSum);
                            break;
                        case 3:
                            //algorithm D.
                            deviationFromIdeal = AlgorithmD.run(tempS,idealSum);
                            break;
                        case 4:
                            //algorithm E.
                            deviationFromIdeal = AlgorithmE.run(tempS,idealSum);
                            break;
                        case 5:
                            //algorithm F.
                            deviationFromIdeal = AlgorithmF.run(tempS,idealSum);
                            break;
                        case 6:
                            //algorithm G.
                            deviationFromIdeal = AlgorithmG.run(tempS,idealSum);
                            break;
                        case 7:
                            //algorithm H.
                            //Current hardware that student 2103400 uses is insufficiently slow,
                            // with the 2103400 hard running for 10 minutes to run algorithm H with
                            // an array of size 32.
                            //The code below prevents algorithm H from running if the size is greater than 16
                            if(!(size > ALGORITHM_H_SIZE_LIMIT)){
                                deviationFromIdeal=AlgorithmH.run(tempS,idealSum);
                            }
                            break;
                        case 8:
                            deviationFromIdeal = AlgorithmI.run(tempS,idealSum);
                            break;
                    }

                    //add the data to the result table. The condition is there to prevent the program
                    //from attempting to add data from algorithm H when algorithm H has not run.
                    if(!(ALGORITHM_NAMES[currentAlgorithm].equals("H") && size > ALGORITHM_H_SIZE_LIMIT)){
                        results.getCell(size,ALGORITHM_NAMES[currentAlgorithm]).addElement(deviationFromIdeal);
                    }
                }
            }
        }

        //Then, the mean and standard deviation are calculated and stored for each cell.
        for(int size: ARRAY_SIZE){
            for (int currentAlgorithm = 0; currentAlgorithm < ALGORITHM_NAMES.length; currentAlgorithm++){
                //this goes through the entire table and retrieves its data.
                ArrayList<Float> tempData = results.getCell(size,ALGORITHM_NAMES[currentAlgorithm]).getData();
                if(tempData.size() == 0){
                    //If the data is empty (would be false for algorithm H, with size 32 and greater.),
                    //then skip to the next cell.
                    continue;
                }

                //This calculates the mean and standard deviation of the cell.
                float tempMean = calcMean(tempData);
                float tempStandardDeviation = calcStandardDeviation(tempData);

                //This replaces the data in the cell with the mean and standard deviation.
                //in format (mean deviation from the ideal, the standard deviation of the deviation
                //from the ideal partition).
                results.getCell(size,ALGORITHM_NAMES[currentAlgorithm]).clearCell();
                results.getCell(size,ALGORITHM_NAMES[currentAlgorithm]).addElement(tempMean);
                results.getCell(size,ALGORITHM_NAMES[currentAlgorithm]).addElement(tempStandardDeviation);

            }

        }

        //This writes the data to a CSV file
        outputResults(results);

    }
    public static void outputResults(Table results){
        //This writes the output information to a CSV file

        //This goes through each cell
        try{
            FileWriter fileWriter = new FileWriter("results.csv");

            //1st, the program will create the headings for the means
            //Also, there isn't a neat way of just inputting the standard deviation with
            //1 command in Excel. Instead, manual input is required for each line to plot error bars.
            //this means The program will have a mean section and a standard deviation section in the
            //CSV file
            //1st heading is empty, so Excel will treat that column as the x-axis. (excel-easy,2022)
            String meanHeadings = ",";
            for(String Algorithm: ALGORITHM_NAMES){
                meanHeadings += "Algorithm"+Algorithm+",";
            }
            meanHeadings += "\n";
            fileWriter.write(meanHeadings);

            //This code repeats twice. Once for the mean and once for the standard deviation.
            //0 = mean, 1 = standard deviation
            //This paper used the definition for a statistic defined by Merriam-Webster (n.d.).
            for (int statistic = 0; statistic < 2; statistic++){
                for(int size: ARRAY_SIZE){
                    String currentLine = Integer.toString(size);
                    //Look up either the mean or standard deviation of the current algorithm, and add it to the
                    //current line
                    for (int currentAlgorithm = 0; currentAlgorithm < ALGORITHM_NAMES.length; currentAlgorithm++){
                        //this gets the mean and standard deviation for a specified algorithm and array size.
                        ArrayList<Float> tempData=results.getCell(size,ALGORITHM_NAMES[currentAlgorithm]).getData();
                        if(tempData.size() == 0){
                            //If the data is empty (would be false for algorithm H, with size 32 and greater.),
                            //then skip to the next cell.
                            currentLine += ",";
                            continue;
                        }
                        //This adds the data to the current line.
                        currentLine += ","+Float.toString(tempData.get(statistic));
                    }
                    //then tell the program to start a new line and then output it to the file
                    currentLine += "\n";
                    fileWriter.write(currentLine);
                }
                if (statistic == 0){
                    //If the program is done writing the mean information, then format data slightly differently
                    fileWriter.write("\n\n\n");
                }
            }



            fileWriter.close();
        } catch (IOException e){
            System.out.println("Error creating file");
        }

    }
    public static float calcMean(ArrayList<Float> data){
        //this calculates the mean of data
        float mean = 0;
        for(float element: data){
            mean += element;
        }
        mean /= data.size();

        return mean;
    }

    public static float calcStandardDeviation(ArrayList<Float> data){
        //This calculates the standard deviation
        float mean = calcMean(data);

        float deviation = 0;
        for (float element: data){
            deviation += Math.pow((element - mean), 2);
        }
        float standardDeviation = (float) Math.sqrt(deviation / (data.size() - 1));

        return standardDeviation;
    }
    public static int[] generateS(int size){
        //this generates S in the range 10*size<=S<=100*size
        int[] s=new int[size];
        int currentIndex=0;
        //used (3) https://www.educative.io/answers/how-to-generate-random-numbers-in-java
        Random random=new Random();

        //this will loop until s is fully populated
        while(currentIndex != size){
            //generate a random number between 0 and 100*size inclusive
            int ranNum=random.nextInt((size*100)+1);
            if(ranNum>=(size*10)){
                //if the number is less than 10*size, repeat, otherwise add it to s and continue
                s[currentIndex]=ranNum;
                currentIndex+=1;
            }
        }
        return s;
    }

}
