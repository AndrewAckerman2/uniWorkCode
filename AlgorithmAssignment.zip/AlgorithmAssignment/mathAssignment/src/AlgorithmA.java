public class AlgorithmA {
    public static float run(int[] s, float idealSum){
        //Add the 1st half of values to s1, and the other half to s2
        int sumS1 = 0, sumS2 = 0;
        for (int currentIndex = 0; currentIndex < s.length; currentIndex++){
            if (currentIndex < (s.length / 2)){
                //Add the 1st half of values to s1
                sumS1 += s[currentIndex];
            } else {
                //Add the 2nd half of values to s2
                sumS2 += s[currentIndex];
            }
        }

        //This returns the absolute difference between the ideal partition
        //and the sum of S1, which coincidentally equals the absolute
        //difference between the ideal partition and the sum of S2.
        return Math.abs(idealSum - sumS1);
    }
}
