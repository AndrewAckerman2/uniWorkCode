import java.util.ArrayList;

public class Cell {
    //this stores a cell. Student 2103400 does not know how to store a 2d list,
    //of datatype ArrayList.
    private ArrayList<Float> data;
    public Cell(){
        this.data=new ArrayList<>();
    }
    public void addElement(float element){
        data.add(element);
    }

    public ArrayList<Float> getData(){
        return this.data;
    }

    public void clearCell(){
        //this empties the cell
        this.data.clear();
    }

}
