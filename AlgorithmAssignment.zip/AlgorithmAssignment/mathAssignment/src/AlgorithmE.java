public class AlgorithmE {
    public static float run(int[] s, float idealSum){
        //Sort S in ascending order, then add even indices to S1 and add
        //the elements with odd indices to s2.

        //This sorts S into ascending order.
        Main.ascendingQuickSort(s,0, s.length-1);

        int sumS1 = 0, sumS2 = 0;
        for (int currentIndex = 0; currentIndex < s.length; currentIndex++){
            if (currentIndex % 2 == 0){
                //If the index is even, the result will be added to S1
                sumS1 += s[currentIndex];
            } else {
                //If the index is odd, the result will be added to S2
                sumS2 += s[currentIndex];
            }
        }

        return Math.abs(idealSum - sumS1);
    }
}
