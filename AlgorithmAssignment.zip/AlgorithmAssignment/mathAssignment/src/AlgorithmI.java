public class AlgorithmI {

    public static float run(int[] s, float idealSum){
        //This is an example of the Karmarkar–Karp heuristic (Stevenson, 2022).

        //This algorithm is poorly designed due to time constraints.
        //Student 2103400 was not able to correctly derive the equations for
        //how to find the index position of the parent node from the
        //perspective of a child node in a Max heap, so to get an
        //algorithm down for marks, Student 2103400 had to come up
        //with a working but inefficient algorithm for Algorithm I.


        for (int elementsExcluded = 0;elementsExcluded < s.length - 1; elementsExcluded++){
            //This sorts the items into ascending order so that the program can find the 2
            //largest items.
            Main.descendingQuickSort(s, elementsExcluded,s.length-1);

            //then 2nd


            //The 2nd largest element becomes equal to the difference between the 2
            //largest integers. The list is then sorted, excluding the biggest
            //number in the list. This is equivalent to removing the two biggest
            //elements from the array, and adding the difference to the set.
            //This repeats until there is the only element in the array
            s[elementsExcluded+1] = Math.abs(s[elementsExcluded] - s[elementsExcluded+1]);
        }

        return (float)s[s.length-1] / 2;

    }
}

