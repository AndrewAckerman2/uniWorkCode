public class AlgorithmC {
    public static float run(int[] s, float idealSum){
        //Add the all even values to s1, and all odd values to s2
        int sumS1 = 0, sumS2 = 0;
        //This goes through every element in S.
        for(int currentElement: s){
            if (currentElement % 2 == 0){
                //If the value is even, the result will be added to S1
                sumS1 += currentElement;
            } else {
                //If the value is odd, the result will be added to S2
                sumS2 += currentElement;
            }
        }

        return Math.abs(idealSum - sumS1);
    }
}
