public class AlgorithmG {
    public static float run(int[] s, float idealSum){
        //sort S into descending order, then add 1st element to s1, the 2nd
        //element to s2, then go through the rest, adding the current
        //element to the smallest sum. If s1=s2, add the current element to S1.
        int sumS1 = 0,sumS2 = 0;

        Main.descendingQuickSort(s,0,s.length - 1);
        sumS1 += s[0];
        sumS2 += s[1];
        //This starts at 3rd element of the S
        for (int currentIndex = 2; currentIndex < s.length; currentIndex++){
            if (sumS2 >= sumS1){
                //If S2 is bigger or equal to s1, the current element will
                //be added to S1.
                sumS1 += s[currentIndex];
            } else {
                //If S1 is bigger than s2, the current element will be
                // added to S2.
                sumS2 += s[currentIndex];
            }
        }
        return Math.abs(idealSum - sumS1);
    }
}
