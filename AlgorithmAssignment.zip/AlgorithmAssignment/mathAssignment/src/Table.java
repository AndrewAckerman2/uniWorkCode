import java.util.HashMap;

public class Table {
    //Values in format [column, row]


    //think of this as a 2d dictionary, which can store an array as input.
    //this will act as a table, with each cell storing an array of information
    //
    //
    //This translates between the label and the column number
    private HashMap<Integer,Integer> column=new HashMap<>();
    //this translates between the label and the row number
    private HashMap<String,Integer> row=new HashMap<>();


    //this stores the data
    private Cell[][] allCells;


    public Table(int[] xLabels,String[] yLabels){
        //this is basically a 2d dictionary.
        for(int columnNumber = 0; columnNumber < xLabels.length; columnNumber++){
            this.column.put(xLabels[columnNumber],columnNumber);
            //this translates between the key and the cell position column number
        }
        for(int rowNumber = 0; rowNumber < yLabels.length; rowNumber++){
            this.row.put(yLabels[rowNumber],rowNumber);
            //this translates between the key and the cell position row number
        }
        //this is where the data is stored.
        this.allCells=new Cell[xLabels.length][yLabels.length];

        //This populates the Table with Cells.
        for (int columnNumber = 0; columnNumber < xLabels.length; columnNumber++){
            for(int rowNumber = 0; rowNumber < yLabels.length; rowNumber++){
                this.allCells[columnNumber][rowNumber]=new Cell();
                //this translates between the key and the cell position row number
            }
        }


    }

    public Cell getCell(int columnLabel,String rowLabel){
        return allCells[column.get(columnLabel)][row.get(rowLabel)];
    }


}
