public class AlgorithmB {
    public static float run(int[] s, float idealSum){
        //Add values of indices arrays to S1, and odd indices to S2
        int sumS1 = 0, sumS2 = 0;
        //It appears that putting the s.length in the for loop has
        // the same time efficiency as creating a variable earlier and
        //making it equal to s.length and putting that variable
        // into the for loop.

        //This goes through the entire array
        for (int currentIndex = 0; currentIndex < s.length; currentIndex++){
            if (currentIndex % 2 == 0){
                //If the index is even, the result will be added to S1
                sumS1 += s[currentIndex];
            } else {
                //If the index is odd, the result will be added to S2
                sumS2 += s[currentIndex];
            }
        }

        //Storing S1 or S2 is unnecessary as S1 and S2 is never used.
        //Instead, we only need to store their sum.
        return Math.abs(idealSum - sumS1);
    }
}
