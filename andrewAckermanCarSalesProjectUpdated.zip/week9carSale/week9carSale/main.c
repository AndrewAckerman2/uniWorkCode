//program that advertises car sales, offers information on price and availability, takes orders, charges for cars sold and keeps track of how many cars remain available
//Greet the user
//Offer information on price of cars and how many are available
//Ask how many they want to purchase
//Allow the user to enter the number of cars they want
//Update the number of available cars and display it
//Offer a discount based on certain criteria, e.g.age range
//Check if discount criteria are metand apply the discount
//Calculate priceand tell them how much it costs

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
//this library defineds constants like NULL.
#include <stdlib.h>
#include <errno.h>
#include  <limits.h>
#include  <ctype.h>
//define the global variables/constants

//defining the constants.

//This is the percentage the total price is reduced by when given a discount.
#define CAR_DISCOUNT_AMOUNT .30f

//also stole a the persons code for defineing min and max discount age as constants rather than refuring to the numbers when i would use them in an compairison statement, since this way 
//I will treat them as constants rather than variables and this will improve readablility.
#define MINIMUM_DISCOUNT_AGE 18.0
#define MAXIMUM_DISCOUNT_AGE 30.0

//the next 3 constants are used to improve readability. They are used to tell what option the user has selected
//eg. if they want to buy cars, 
#define MENU_VIEW_CAR_TYPES_OPTION 'a'
#define MENU_BUY_CARS_OPTION 'b'
#define MENU_VIEW_SALES_INFO_OPTION 'c'
#define MENU_EXIT_OPTION 'x'

//also true and false are useful.
#define TRUE 1
#define FALSE 0

//these are used when trying to see if a input number is a number, basically they act as reference to a datatype.
#define DATA_TYPE_SIGNED_SHORT_INDEX 0 
#define DATA_TYPE_UNSIGNED_SHORT_INDEX 1
#define DATA_TYPE_SIGNED_INT_INDEX 2
#define DATA_TYPE_UNSIGNED_INT_INDEX 3
#define DATA_TYPE_SIGNED_LONG_INDEX 4
#define DATA_TYPE_UNSIGNED_LONG_INDEX 5
#define DATA_TYPE_FLOAT_INDEX 6
#define DATA_TYPE_DOUBLE_INDEX 7




//this is equal to the maximum amount of purchases the user can make. It should equal the number of cars in stock.
//Has to be a constant since it is used when defining the other purchase history arrays maximum size. Though
//due to how c works, the program has to know the value when it is compiled, so i can't create a calculate how many
//cars are in stock at the beginning and then assign that value to the constant, since c won't know that when it is 
//compiled. So you may ahve to calculate it mannuelly, and then plug that value into the constant. Or you could create
//another program that plugs that value into this program before this one runs.
#define MAX_RECEIPTS 55
//I called it max reciepts not max sales since for me 1 sale is a purchase of 1 item.eg if you buy 3 cars at
//once, it would be 3 sales, but 1 receipt. so receipt for me feels more appropiate.

//this is the maximum length of any given name
#define MAX_NAME_LENGTH 201

//global variables

//next are the arrays about the of cars themselves. specifically the type of car. These arrays index represents the 
//type of car, and the element represents info about the car type.


//this is a array containing the amount of each type of car, eg there is 5 type 1 cars, there are 3 type 2 cars
unsigned int amountOfEachCarTypeLeftList[] = { 15, 14, 12, 14 };

//this array contains the price of each car type, 
unsigned int priceOfCarType[] = { 10000, 20000, 30000, 40000 };

//this array contains the name of each type of car
char nameOfCarType[][MAX_NAME_LENGTH] = { "Type0", "Type 1", "Type 2", "Type n" };

//this array is an array with each element refuring to the index position of the.index refuring to the type of car
//I will explain more about this latter when i Am sorting the arrays, but effectively, this is an array where each element refurs an individual
//car type, or more specifically, since The index positions of the previous 3 arrays were referencing a different car type, this is an array
//whose elements refur to the car type. so 0 refurs to car 0, 1 refurs to car 1 etc. however where this gets intresting, is that since for 
//this array, the index implicityly represent the car type, thats the elements job. so the array can be unordered, eg [1,0,3,2], and as the
//othere lists won't be ruined depending if the oder changes. so 1,0,3,2 means car 1, then car 0, the car 3, then car 2. By separating the 
//concept of index position and the type of car type, this allows me to do more operatiosn effectively.

//for example say i wanted to output the car types in order of how many cars there are left. without the array below, if i changed the elements
//in the amountOfEachCarTypeLeftList array, then I would have to change the other 2 lists about the other car types if I do want to the index 
//position of those arrays to represent the car type. This would add more operations to program, which is undesireable. However, if have an array
//where each element refurs to the indecx position of a car type, then I can swap the items in pointer array while not elininating the meaning
//of the previous array's indexs. furthermore it is easier to unsort if i need to unsort the array.
int arrayOfCarTypePointers[] = { 0,1,2,3 };

//the next 4 arrays are about information receipts, more specifically containing the history of receipts and the respecitve info about it
//the index shared between all of them is the time of purchase or the numberOfReceipts

//first this array contains the number of cars sold per purchase
unsigned short numbCarsSoldPerReceiptHistoryList[MAX_RECEIPTS];
//this shows if a discount was given per perchase
unsigned short wasDiscountGivePerReceiptHistoryList[MAX_RECEIPTS];
//this shows the type of car sold per purchase, the elements being an index refuring to the priceOfCarType lsit
unsigned short typeOfCarSoldPerReceiptHistoryList[MAX_RECEIPTS];
//this is a array containing the names of the users that purchased the items, this isn't a array of everyone who purchased items, this is a list of reciepts, ordered buy time of purchase/when you purcased something 
// relative to all other pruchases. the contents are names of the purchaser.
char userNameHistoryList[MAX_RECEIPTS][MAX_NAME_LENGTH];
//this array records the customers age in years. is a float because the loss in precision is irrelevant for age, since we aren't using it for an arithmetic calculation
float customerAgeHistoryList[MAX_RECEIPTS];

//this array serves a similer function to the arrayOfCarTypePointers array, but the elements will be when something was purchased(number of receipts).
int customerPurchaseHistoryPointerArray[MAX_RECEIPTS];


//now I am going to make my porgam less effiecent due to the objestive in car sales program
//5%: Buying a Car needs to record the total price/customer name/customer age/if discount was given/discount value/number of tickets and update existing car arrays as necessary once a sale is concluded
//it wants me to explicitly record total price and discount value, despite the fact that wwith the previous arrays I have, I can durive those values at will, so i would be implicitly sotring the 2 values. but no, you need to to explicitly record the values total price
//and discount value, which will use more mememory, so i will make my program worse for the sake of marks.

//this records the total price for each purchase
long amountOfMoneyGainedPerPurchaseArray[MAX_RECEIPTS];
//this records the discount value per purchase
long discountValuePerPurchaseArray[MAX_RECEIPTS];




//finally there is this variable. This effectively acts as a way to measure time, or more specifically, what order did
//the user purchase an item in.



unsigned int numberOfReceipts = 0;

//file constants and variables



//I am not grouping the all the constants and variables in 1 place and instead are putting these file constants/variable in 1 place to improve 
//readability. The purpose of grouping all the constants together and all the variables togeter is to know where the variable/constant data
//is located. However, since file stuff is only going to be used for files, it may be better to have the file stuff grouped together, so I
//don't need to search the constants and variables for the file constants/variables


//these are there to increase readability for the code. I am making the state of opening/closing the file constant.
//These contants won't be created by the in library text file functions like fopen(), fclose() etc, but instead will be used by my program.
#define FILE_OPENED 0
#define FILE_CLOSED 1
#define FILE_ERROR 2

//is the Name of file need to have 2\\ instead of 1\ because since the adress below is a string, \\ = \ but a single backslash is a command thingy
//like \n etc.
//#define DEFAULT_FILE_NAME "H:\\My Documents\\Development\\Year_1\\IntroToProg\\week11\\week9carSale.data.csv"
#define DEFAULT_FILE_NAME "C:\\Users\\Andre\\Desktop\\Development\\Year_1\\Intro_To_prog\\week12\\week9carSale\\data.csv"
// "C:\\Users\Andre\Desktop\Development\Year_1\Intro_To_prog\week12\week9carSale\data.csv
//defineing the file name.
FILE* file;

//used if i ever want to change the file opened.
char currentFileName[201] = DEFAULT_FILE_NAME;


//file functions
//unsigned char since want to save memory, and char has 1 Byte of memory while int,short etc have more memory dedictated to each avriable(4,2 
//bytes repectively).
unsigned char fileState = FILE_CLOSED;

//next variables are for errno stuff
extern int errno;

//Functions
int checkIfSignIsPresent(char* userInputValue) {
	//this checks if a sign is present
	if (userInputValue[0] == '+' || userInputValue[0] == '-') {
		//sign is present so return true
		return TRUE;
	}

	//no sign is present so return false
	return FALSE;
}

void findDataTypeMinAndMax(char* minimumDataTypeValue, char* maximumDataTypeValue, int currentDataType) {
	//this function is about getting outputing the the mimum and maximum values of a data type into a string. 
	switch (currentDataType) {
	case DATA_TYPE_SIGNED_SHORT_INDEX:
		sprintf(maximumDataTypeValue, "%+d", SHRT_MAX);
		sprintf(minimumDataTypeValue, "%+d", SHRT_MIN);
		break;
	case DATA_TYPE_UNSIGNED_SHORT_INDEX:
		sprintf(maximumDataTypeValue, "%u", USHRT_MAX);
		sprintf(minimumDataTypeValue, "%u", 0);
		break;
	case DATA_TYPE_SIGNED_INT_INDEX:
		sprintf(maximumDataTypeValue, "%+d", INT_MAX);
		sprintf(minimumDataTypeValue, "%+d", INT_MIN);
		break;
	case DATA_TYPE_UNSIGNED_INT_INDEX:
		sprintf(maximumDataTypeValue, "%u", UINT_MAX);
		sprintf(minimumDataTypeValue, "%u", 0);
		break;
	case DATA_TYPE_SIGNED_LONG_INDEX:
		sprintf(maximumDataTypeValue, "%+ld", LONG_MAX);
		sprintf(minimumDataTypeValue, "%+d", LONG_MIN);
		break;
	case DATA_TYPE_UNSIGNED_LONG_INDEX:
		sprintf(maximumDataTypeValue, "%lu", ULONG_MAX);
		sprintf(minimumDataTypeValue, "%lu", 0);
		break;
	case DATA_TYPE_FLOAT_INDEX:
		//i didn't have enough time to generalize this to float and double values
		break;
	case DATA_TYPE_DOUBLE_INDEX:
		//i didn't have enough time to generalize this to float and double values
		break;
	default:
		printf("\ndeveloper put wrong arguements in this function\n");
		break;
	}
}

int getNumberOfDecimalPointsInString(char* posibleFloatNumber) {
	//this returns the number of decimal points in a string. used for checking is a real number is a real number

	//this works because strchr(str1,'a') returns a pointer that either points to NULL if there are no 'a' charaters in the string, in which case
	//we would return 0, or it returns a pointer pointing to the first instance of the 'a' charater. by using recursion, we can find the number
	//pf decimal points in the string quite easily

	char* newPosibleFloatNumber = strchr(posibleFloatNumber, '.');

	if (newPosibleFloatNumber == NULL) {
		//if no decimal points were found, return 0
		return 0;
	}
	else {
		//note the arguement we are passing into the function is the pointer (newPosibleFloatNumber + 1), which basicaly means the string
		//after the the first decimal point. if we did (newPosibleFloatNumber), then this would go on forever.
		//eg if it was (newPosibleFloatNumber) and we tried to see it "hi." had a decimal point in it, it the pointer would be equal to
		//".", and then "." would be passed into the function. then we would see if the string "." had a decimal point in it, which is does
		//so it would enter into the function again. this would repeat forever. by adding 1 to the pointer, we are excluding the found
		//decimal point.
		return getNumberOfDecimalPointsInString((newPosibleFloatNumber + 1)) + 1;
	}
}

int checkIfNumberIsNumber(char userInput[201], int currentDataType) {
	//this checks if a number is a number. Specifically, it checks if the input, with infinite memory and regardless of data types, 
	//checks if an input could theoretically be a number. and with It will return true If it is a number, false if it isn't a number

	//this is if a number is present
	int isNumberPresent = FALSE;
	//is equal to the number of decimal points in the number
	int numberOfDecimalPoints = getNumberOfDecimalPointsInString(userInput);

	//if the value is integer and it has a decimal point return false else, con tinue
	if (!(!(currentDataType == DATA_TYPE_FLOAT_INDEX || currentDataType == DATA_TYPE_DOUBLE_INDEX) && numberOfDecimalPoints >= 1)) {
		if ((currentDataType == DATA_TYPE_FLOAT_INDEX || currentDataType == DATA_TYPE_DOUBLE_INDEX) && numberOfDecimalPoints >= 2) {
			//if the value is a float/double value and has more than 1 decimal point return false
			return FALSE;
		}

		int lenOfUserInput = strlen(userInput);

		//So if the number is +ve or -ve, then we would want to skip the 1st charater of the string. so if a sign is present, the starting position in the
		// loop is 1. if no sign is present, the starting position in the loop is 0.
		int startPositionInLoop = (checkIfSignIsPresent(userInput) == TRUE) ? 1 : 0;

		//now we need to check if the sting has enough charaters to be able to loop it. In other words we need to know if
		//the string is either a) empty or b)Just a '+' or '-' sign.
		//for a), the length of the string must be 1 or more, and since startPositionofLoop = 0, that means 1+0=0, so the 
		//condition below holds true. for b), we want to have a number, so it must have at least 2 charaters a ('+' or '-')
		//and at least 1 number. which in that case, (1+startPositionOfLoop) = 2. so the condition holds.
		if (lenOfUserInput >= (1 + startPositionInLoop)) {
			//entering here means the input is not just a '+' or '-' 
			for (int letterIndex = startPositionInLoop; letterIndex < lenOfUserInput; letterIndex++) {
				if (isdigit(userInput[letterIndex]) != FALSE) {
					//if the number is not a decimal point, then we should check if it is a number between 0 and 9
					isNumberPresent = TRUE;
					//here to check if the charater is a number
				}
				else if (userInput[letterIndex] != '.') {
					//If we receive a decimal point, and we have made it to this for loop, then there are either no decimal points in the case
					//of the value being an integer, or there is 1 decimal point in the case of the value being a real number. 
					//this means if we encounter a decimal point, we do'n want to do anything. So this is saying if we encounter a value that is 
					//neither a decimal point or a number, then we do not have a valid number, so stop
					return FALSE;

				}
			}
		}

		else {
			//if the user entered '+' or '-' or '' on its own, then the string is not a number, so return false
			return FALSE;

		}
		if (isNumberPresent == TRUE) {
			//This means if there were only numbers present in the input, and every other condition was true, then the input was a number, 
			// so return TRUE. I need this separately, since the number may have decimal points in it.
			return TRUE;
		}


	}
	//if the user entered an integer value which has decimal points, return false.
	return FALSE;
}

int getIntegerInput(char* userStringInputBuffer) {
	//this converts an string value to a integer value
	int integerInput = atoi(userStringInputBuffer);
	return integerInput;
}

float getFloatInput(char* userStringInputBuffer) {
	//this converts an string to a float
	float floatOutput = (float)atof(userStringInputBuffer);
	return floatOutput;
}

unsigned short getUnsignedShortInput(char* userStringInputBuffer){
	//this converts an string value to a unsigned short value
	//atoi returns an int type, but since we already know the value of the userStringInputBuffer is within the domain of the unsigned short type, 
	//this means we can just convert to a integer using atoi, and then use casting to convert to an unsigned short type.
	unsigned short unsignedShortInput = (unsigned short)atoi(userStringInputBuffer);
	return unsignedShortInput;
}


void getStringInput(char* userStringInput, int maximumInputSize) {
	//this gets a string user input from the console, and the program will not crash if the input is to big.
	//first we will get the input
	fgets(userStringInput, maximumInputSize, stdin);

	//this will detect if the string has a newline charater in the string, if so, remove it. I need to check because if the input is to big,
	//newline charater will go to the buffer register and will not be stored in the string input. but if the input is at an apropiate size
	//then the newline charater will be in the string and so i will need to remove it
	if (strchr(userStringInput, '\n') != NULL) {
		//so if the newline charater is present, replace it with the NULL charater.
		userStringInput[strlen(userStringInput) - 1] = '\0';
	}
}

int checkIfDataTypeSigned(int currentDataType) {
	//this checks if the current data type is signed or not. if current data type is signed return TRUE. else return FALSE
	switch (currentDataType) {
		case DATA_TYPE_SIGNED_SHORT_INDEX:
			return TRUE;
		case DATA_TYPE_SIGNED_INT_INDEX:
			return TRUE;
		case DATA_TYPE_SIGNED_LONG_INDEX:
			return TRUE;
		case DATA_TYPE_DOUBLE_INDEX:
			return TRUE;
		case DATA_TYPE_FLOAT_INDEX:
			return TRUE;
		}

	//if program makes it here the the data type is unsigned, so return false
	return FALSE;
}

int compair2Integers(int num1, int num2) {
	//this function compairs 2 integers.
	//if num1 is less than num 2, return 1. if num 1 is bigger than num 2 return 1. if num 1==num2 return 0.
	if (num1 < num2) {
		return 1;
	}
	else if (num1 > num2) {
		return -1;
	}
	return 0;
}

int checkIfIntegralValueIsBiggerThanMaxDataTypeValue(char* userInputValue, char* minimumDataTypeValue, char* maximumDataTypeValue, int currentDataType,
	int isSignPresent, int isDataTypeSigned) {
	//this checks to see the user value is bigger than the data type the value will be stored in.
	//this is used to compair either unsigned values, or an signed value that has no sign( so it is implicitly positive)
	//if it has no sign but the data type is signed, then ignore the first charater when You are compairing the strings.( so starting position=1).
	//if the data type is unsigned then starting position equal 0.
	int startingPosition = (isSignPresent == FALSE && isDataTypeSigned == TRUE) ? 1 : 0;

	//stores the result of the string compairison.
	//if the result is 0, then the both the user input value and the datatype value equal eachother, which is ok. if the result is -ve then the result is ok
	//if the result is +ve, then the userValue exceeds the datatype range, which is not ok
	int resultOfStringCompairison;

	if (userInputValue[0] == '-') {
		//here we are compairing negative values. but it works exactly like positive values.
		resultOfStringCompairison = strcmp(userInputValue, minimumDataTypeValue);
	}
	else {
		resultOfStringCompairison = strcmp(userInputValue, (maximumDataTypeValue + startingPosition));
	}

	if (resultOfStringCompairison <= 0) {
		return TRUE;
	}


	//otherwise tell user result is out of range, and then return false
	printf("Result is out of range. Please try again. Answer:");
	return FALSE;
}

int checkIfIntegralToBigToBeStoredInIntegralDataType(char* userInputValue, char* minimumDataTypeValue, char* maximumDataTypeValue, int currentDataType) {
	//this checks if a the user input is to big to be stored in the datatype it is tring to be store in, eg, are you tring to store 2^32+1 into
	//an integer value. if so an overflow will occur. even though this is partially solved by getStringInput() function, since inputs that are to 
	//big will be cut off, eg if you want a 5 charater number 55555555 will be turned to 55555. but while that is good for proventing integer
	//overflows that will change the users input. and that getStringInput() function also doesn't solve the storing 2^32+1 into an integer problem
	//either.

	//1 way of solving this is that if in the getStringInput() function, the maximum size allows you to have a bigger number than the datatype
	//you are tring to store a vazlue in, eg for a short value if the function allows you to enter 7 or 8 figures, since 2^16 is around 65536 
	//which is 5 digits, then if you are trying to store a bigger number than 2^16, it will either have more digits even if the value is cut off
	//by the string charater limit, or it is 5 charaters long, in which case we will need to compair the numbers sizes. this will allow us to 
	//see if an integral input is to big to be stored in the data type it is being stored in

	//this variable only comes into play if both the input data the the datatype data are the same size.
	int resultOfTheSizeCompairison;

	//length of input
	int lengthOfUserInput = strlen(userInputValue);

	//for signed values the minimum value and the maximum value has the same  number of charaters
	int lengthOfDataTypeMaxValue = strlen(maximumDataTypeValue);

	//used to record the result of values being compaired
	int compairLengthOfStrResult = 0;

	//check if the value has a sign in front of it
	int isSignPresent = checkIfSignIsPresent(userInputValue);

	//then i check if the data type is signed
	int isDataTypeSigned = checkIfDataTypeSigned(currentDataType);

	//what this is saying is that if the value is suposed to be unsigned but the value has a sign in it, show an error message and return FALSE 
	if (!(isDataTypeSigned == FALSE && isSignPresent == TRUE)) {
		//if an unsigned data has no sign, or if a signed data type has a/no sign on the number, then continue on.

		//now we are compairing the lengths of the input value and the maximum value.
		if (isDataTypeSigned == FALSE || (isDataTypeSigned == TRUE && isSignPresent == TRUE)) {
			//this compairison occurs if either both numbers have signs or neither number has signs.
			compairLengthOfStrResult = compair2Integers(lengthOfUserInput, lengthOfDataTypeMaxValue);

		}
		else if (isDataTypeSigned == TRUE && isSignPresent == FALSE) {
			//if a signed value has no sign, then we subtract 1 from the length of the data type max value, so we excluding the sign when compairing the lengths.
			compairLengthOfStrResult = compair2Integers(lengthOfUserInput, lengthOfDataTypeMaxValue - 1);
		}

		if (compairLengthOfStrResult == 1) {
			//then that means the user input was withing the correct size, and hence we have verified that their input can be stored in the variable.
			return TRUE;

		}
		else if (compairLengthOfStrResult == -1) {
			//then user input value was bigger than the maxiumum value
			printf("The value entered was to big. Please try again. Answer:");
			return FALSE;
		}
		else if (compairLengthOfStrResult == 0) {
			//this means that both the user input and the maximumValue for the datatype are the same size. This means we need to look a bit closer at the values
			//char *result
			resultOfTheSizeCompairison = checkIfIntegralValueIsBiggerThanMaxDataTypeValue(userInputValue, minimumDataTypeValue, maximumDataTypeValue,
				currentDataType, isSignPresent, isDataTypeSigned);
			if (resultOfTheSizeCompairison == TRUE) {
				//if the value is acceptable, return true
				return TRUE;
			}
			else {
				//otherwise return false.
				return FALSE;
			}
		}
	}

	printf("Value entered was not a valid value. Please try to not put + or - signs into the answer. Please Try Again. Answer: \n");
	//this return statement is not in a else statement, since if i need to return a value, I need to explicitly have a return value that is in the scope of 
	//the function, eg not in any if/else/other indented blocks of code. 
	//this statement occurs when you are tring to store a signed value in an unsigned data type.
	return FALSE;
}

int checkIfValueIsAnIntegral(char* strInputBuffer, int currentDataType) {
	//this sees if a value is a valid integral value. will use type casting to convert from long to short or int. 
	//these will store the minimum and maximum value the datatype can store

	//i wasn't able to fully generize this function to floats, due to time. 

	char minimumDataTypeValue[30];
	char maximumDataTypeValue[30];

	int resultOfCheckingIsValueToBigToBeStoredInDataType;
	//then I check if the value can be stored in as a number, e.g. does it follow the conventions that number systems follow
	int isNumberANumber = checkIfNumberIsNumber(strInputBuffer, currentDataType);

	if (isNumberANumber == TRUE) {
		//if a number follows the conventions of writing a number, then continue.
		//then i will find the minumum and maximum data type values
		findDataTypeMinAndMax(minimumDataTypeValue, maximumDataTypeValue, currentDataType);

		//then checkijng if an integral value can be stored in the variable
		resultOfCheckingIsValueToBigToBeStoredInDataType = checkIfIntegralToBigToBeStoredInIntegralDataType(strInputBuffer,
			minimumDataTypeValue, maximumDataTypeValue, currentDataType);

		//if the integral value can be stored, return true. otherwise return false.
		if (resultOfCheckingIsValueToBigToBeStoredInDataType == TRUE) {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}
	else {
		//value entered was not a number. so output message to user and return FALSE
		printf("\nValue entered was not a number. Please Try again. Answer: \n");
		return FALSE;
	}

}

float convertPenceToPounds(long moneyInPence) {
	//this function converts the an amount of money in pence to the equiventent in pounds. this is purely for the users benifit
	//since I will do the calculations with money in pence as to not add a loating point error. 
	//eg
	//float real1 = 5.0f, real2 = 3.0f;
	//printf("%f", real1 / real2);
	//will output 1.666667, since 5/3 can't be represented exactly, so c needs to choose to round up or down. however so if you multiplied 
	//that by 1000000 you would get 1666667, instead of 1666666, this means money has been generated from nowhere. This is why i am using money as
	//a long value instead of a float value.
	//however the user will be used to values with decimals, so when showing prices to the user, i will output a float value, despite the values being
	//stored as an long value
	float moneyInPounds = (float)moneyInPence / 100;
	return moneyInPounds;

}

void pauseProgram(char userInput,int isValueInBufferRegister) {
	//this pauses the program.
	//these getchar() makes it so the program gets a chance to display the text before the while loop triggers, erasing all the text.
	if (userInput == MENU_EXIT_OPTION || fileState == FILE_ERROR) {
		printf("Please press enter to exit the Program.\n");
	}
	else {
		//if not exit option then this, but not good enough to generalize. maybe if I have program in states.state 1,2,3.
		printf("Please press enter to go back to the menu.\n");
	}
	//if there is a value in the buffer register,then skip this getchar() witch aims to clear out the buffer register.
	if (isValueInBufferRegister==TRUE) {
		getchar();
	}
	getchar();
}

//this clears the screen
void clearScreen() {
	//this clears the console screen of inputs/words. This is a separite function to improve readability
	system("cls");
}

int getNumberOfCarTypes() {
	//this finds the number of car types. e.g. there are 3 types of car, type 1, type 2, and type 3.
	int numberOfCarTypes = sizeof(amountOfEachCarTypeLeftList) / sizeof(int);
	return numberOfCarTypes;
}

void swapIntegers(int* integer1, int* integer2) {
	//this swaps 2 integers
	int temp = *integer1;
	*integer1 = *integer2;
	*integer2 = temp;
}

void bubbleSortLongValues(long* arrayToSort, int* arrayToSortIndexesArray, int arrayToSortSize, char accendOrDecend) {

	//this will sort the arrayToSort, in a fashin. but it won't sort the array itself, but it will instead sort a separate array that represents
	//the indexes of the elements in array to sort assendOrDecend is a constant that will tell the program to sort it in either accending or desceending 
	//order
	//eg say i had an array long arrayToSort = {5, 9, 3, 7, 1}; and long arrayToSortIndexesArray = {0,1,2,3,4}
	//if 5 and 3 are swaped in the first array then we would get {3,9,5,7,1}. but that is indistingishable from swaping the 0 and 2nd positions
	//eg arrayToSortIndexesArray={2,1,0,3,4}. and since each elemnt in this array represents the index position of the arrayToSort, eg 2= element
	//2 in arrayToSort( in this case equals 3), this would allow less operations to take place, since we don't need to sort every other array that
	//shares an index with a similer meaning with array to sort.
	//then I will do bubble sort.
	#define accendingOrderOption 'a'
	#define deccendingOrderOption 'd'

	for (int indexPos1 = 0; indexPos1 < arrayToSortSize - 1; indexPos1++) {
		for (int indexPos2 = indexPos1 + 1; indexPos2 < arrayToSortSize; indexPos2++) {
			//standard bubble sort so far. but here is were is changes.
			//if(var1)
			if (arrayToSort[arrayToSortIndexesArray[indexPos1]] < arrayToSort[arrayToSortIndexesArray[indexPos2]]
				&& accendOrDecend == deccendingOrderOption) {
				//this sorts the values in decending order.

				//this means that the value at index position indexPos1 is less than the value at indexPos2 or array to sort, So
				//I swap the index positions of the values arround, instead of swaping the values. It is a bit confusing, but It generates 
				//the same results. 
				swapIntegers(&arrayToSortIndexesArray[indexPos1], &arrayToSortIndexesArray[indexPos2]);
			}

			else if (arrayToSort[arrayToSortIndexesArray[indexPos1]] > arrayToSort[arrayToSortIndexesArray[indexPos2]]
				&& accendOrDecend == accendingOrderOption) {
				//this sorts the values in accending order

				//this means that the value at index position indexPos1 is bigger than the value at indexPos2 or array to sort, So
				//I swap the index positions of the values arround, instead of swaping the values. It is a bit confusing, but It generates 
				//the same results. 
				swapIntegers(&arrayToSortIndexesArray[indexPos1], &arrayToSortIndexesArray[indexPos2]);
			}
		}
	}


	//furthermore this is a bit generizeable. since if i cast the data type of the array to sort to a long type, this will sort the list fine, 
	//so this will sort integral types up to the long data type. This uses a bit more memory though. but it works.
}

void cleanUpPointerArray(int* pointerArray,int sizeOfArray) {
	//this function resets any array of pointers, or more specifically any arrqay whose values represent the index positiosn of items on other arrays
	//this will help futureproof the function by reseting the values. Since we know these arrays are assentially just a list of accending numbers up
	//to sizeOfArray-1, then we can just copy the values into the array. we can't use a bubblesort to sort the array of values since I would need
	//an array which is bassically a copy of the pointer array before it was sorted. I don't think there is a easy 1 line way of copying an array
	//so that the copied array is independant of the pounter array, so instead i will just take the lazy approach and jsut redirive the array
	for (int indexValue = 0; indexValue < sizeOfArray; indexValue++) {
		pointerArray[indexValue] = indexValue;
	}
}

//functions about opening files
 
FILE* createFile(char* fileName) {
	//this attempts to create a file.
	file = fopen(fileName, "w");

	//then if successfull closes it.
	if (file != NULL) {
		fclose(file);
	}

	//This creates a file, but it also returns the file. this will onloy be called if there is an error with opening the file. If the problem is
	//That the file did not exist, then this will return a not NULL value. But if there is an error woth creating the file, then there must be a
	//bigger error. 
	
	// So This subroutine is being used for 2 purposes, 1 if the file doesn't exist, then make the file exist. 2. narrow down the 
	//type of error that occurs. e.g. is the error due to file not existing or is it something else. the 2nd purpose is why i am returning A file
	//pointer depsite it being global.

	return file;
}

void displayFileError() {
	//this displays the file error and exits the program
	int errorNumber=errno;
	//this outputs the most recent error number, 
	printf("\n\nError number: %d. error message: %s\n",errorNumber,strerror(errorNumber));

	//this allows the user to read the error message
	pauseProgram('_', FALSE);

	//then we will exit the program
	exit(0);
}

//check if file exists, if  not create it.
void openFile(char* fileName,char mode[4]) {
	//this should open the file
	file = fopen(fileName, mode);
	//I am assuming the fileState is opened until proven otherwise
	fileState = FILE_OPENED;

	//if file ==NULL, then there is an error occured
	if (file == NULL) {
		//checking if the error was caused by the file not existing, so I will Create a file.
		if (createFile(fileName) == NULL) {
			//This means an error occured so change the file state to error.
			fileState = FILE_ERROR;
		}

		else {
			//If this else condition occured, then that mean't the file was created succesffullt, so I should try to open the file again.
			file = fopen(fileName, mode);
		}
	}
	printf("%c", fileState);
}

void closeFile() {
	//this function closes the file
	//If the file is open, then want to close it, However If a file is not opened, we don't want to close it, otherwise a crash would occur
	//which is why we have this if condition
	if (fileState == FILE_OPENED) {
		//close file
		fclose(file);
		//fileState becomes closed
		fileState = FILE_CLOSED;
	}
}

void readData_deriveMoneyGainedPerPurchaseAndDiscountAmmount(unsigned short numbCarsSoldValue, unsigned short wasDiscountGivenValue, 
	unsigned short typeCarSoldValue, int lineNumberCounter) {
	//this records the amount of money gained per purchase and the discount amount per purchase from a file. It does this by deriving the 
	//ammount the amount of money gained and the discount value and assigning the derivived values to their respective array.
	//calc price of cars
	long priceOfCars = (long)numbCarsSoldValue * (long)priceOfCarType[typeCarSoldValue];

	//check if discount was given
	if (wasDiscountGivenValue == TRUE) {
		//apply discount
		priceOfCars *= (1 - CAR_DISCOUNT_AMOUNT);
	}
	//then record the amount of money gained per purchase and the discount amount per value
	amountOfMoneyGainedPerPurchaseArray[lineNumberCounter] = priceOfCars;
	//if there is no discount then the discountValuePerPurchaseArray value will be 0.
	discountValuePerPurchaseArray[lineNumberCounter] = ((long)numbCarsSoldValue * (long)priceOfCarType[typeCarSoldValue]) - priceOfCars;

}

void readTypeOfCarsRemainingFromFile() {
	//here I am finding out how many of each car type is remaining
	//first i find number of car types
	int numberOfCarTypes = getNumberOfCarTypes();


	for (int carTypeIndex = 0; carTypeIndex < numberOfCarTypes; carTypeIndex++) {
		//this variable acts as a placeholder for the value amount of cars left
		int amountOfCarTypeLeftValue = 0;
		//then i scan that value
		int scanResult = fscanf(file, "%d", &amountOfCarTypeLeftValue);
		
		//If we are at the end of the file, e.g. the first time we run the program, then quit tring to read values from text file.
		//i put this here since otherwise, i would overwrite all of the amountOfCarTypeLeft values with 0, since at the begining, the text
		//file is empty.
		if (scanResult == EOF) {
			break;
		}
		//then i assign the value to the apropiate array.
		amountOfEachCarTypeLeftList[carTypeIndex] = amountOfCarTypeLeftValue;
	}



}

void readDataFromFile() {
	//this reads data from file to program.

	int lineNumberCounter = 0;

	readTypeOfCarsRemainingFromFile();
	while (TRUE) {
		//tempoarily create variables whos values will be asigned to there respecitve lists.

		unsigned short numbCarsSoldValue, typeCarSoldValue, wasDiscountGivenValue;
		char userNameValue[MAX_NAME_LENGTH]="";
		float customerAgeValue;
		//for now before i write the code to outputing the stuff into a file, lets disregard completely the number of car types left.

		//format will be like below
		//2,1,0,Andrew
		//3,2,1,RealName
		//numberOfCarsSold,TypeOfCarSold,WasDiscountGiven,UserName
		//
		int scanResult = fscanf(file, "%hd,%hd,%hd,%f,%[^\n]s", &numbCarsSoldValue, &typeCarSoldValue, &wasDiscountGivenValue, &customerAgeValue,userNameValue);
		//amountOfEachCarTypeLeftList[];

		//if the file pointer is pointing to the end of the file, then exit the loop
		if (scanResult == EOF) {
			break;
		}
		//strcat(userNameValue, "\0");
		//userNameValue[MAX_NAME_LENGTH - 1] = '\0';
		//otherwise, assign the relevant values scaned in into there respective array
		numbCarsSoldPerReceiptHistoryList[lineNumberCounter] = numbCarsSoldValue;
		wasDiscountGivePerReceiptHistoryList[lineNumberCounter] = wasDiscountGivenValue;
		typeOfCarSoldPerReceiptHistoryList[lineNumberCounter] = typeCarSoldValue;

		//this copies the name from the file to the variable/ copying a max 201 charaters, including the null charater. this is to stop the user
		//from entering names that would break the program.
		//this makes the final charater of the userName value a null terminator, if it is not one allready
		userNameValue[MAX_NAME_LENGTH - 1] = '\0';
		//then i copy the name into the array containing the array.
		strncpy(userNameHistoryList[lineNumberCounter],userNameValue, MAX_NAME_LENGTH);
		customerAgeHistoryList[lineNumberCounter] = customerAgeValue;
		
		readData_deriveMoneyGainedPerPurchaseAndDiscountAmmount(numbCarsSoldValue, wasDiscountGivenValue, typeCarSoldValue, lineNumberCounter);
		//recreating this array. bassically i need an array where each element points to an purchase of an car(s). So if there are 5 initial purchases
		//then there should be 5 eleemnts, 0,1,2,3,4. even better, this quantity is dirivable, i can firgure out this quantity, so I do not need 
		//to write this quantity to a file.
		customerPurchaseHistoryPointerArray[lineNumberCounter] = lineNumberCounter;
		//update the line counter
		lineNumberCounter++;
	}
	//number of reciepts equals the final line number
	numberOfReceipts = lineNumberCounter;
}

void getDataFromFile(char* fileName) {
	//this opens the file and checks if a file is opened or not. and outputs errors based on the result.
	openFile(DEFAULT_FILE_NAME, "r");
	//this 
	switch (fileState) {
		case FILE_OPENED:
			//if file is opened then read data from file
			readDataFromFile();
			break;
		case FILE_ERROR:
			//if error occured, display error message to user and the quit the program.
			displayFileError();
			break;
	}
	//after this i will attempt to close the file, if the file open. the function does nothing if the file is not open though.
	closeFile();

}

void writeNumberOfCarsLeftToFile() {
	//this outputs the first line of the text file, the number of cars left .
	//format, 
	//number of cars left of type 1\n
	//number of cars left of type 2\n
	//...
	//number of cars left of type n\n

	//line is basiically the string file that will be outputed to te csv file
	char line[25] = "";
	//value is a placeholder value, meant to store the number of cars left of a specific type
	char value[20] = "";

	//i then find the number of car types
	int numberOfCarTypes = getNumberOfCarTypes();

	//I then will loop through the amountOfEachCarTypeList to add the remaining amount of each car type to the line string
	for (int carTypeIndex = 0; carTypeIndex < numberOfCarTypes; carTypeIndex++) {
		//this function converts an integer value to a string. Theres a dedicated function since it goes through all the hassel of converting
		//to ASCII etc. I must convert amount to a string since when you are writing to a csv file, you must output a string, not an integer
		_itoa((int)amountOfEachCarTypeLeftList[carTypeIndex], value, 10);
		//then i will reset the line value
		strcpy(line, value);

		//append the\n to the string
		strcat(line, "\n");
		//then I output the file to the csv file.
		fprintf(file, line);

	}
}

void writeDataToFile() {
	//this function writes data to a file.

	writeNumberOfCarsLeftToFile();
	//though techniqually line number isn't accurate, since there is a line before the info about indevidual purchases.
	for (unsigned int lineNumber = 0; lineNumber < numberOfReceipts; lineNumber++) {
		//this contains everything on a line
		char line[310];
		//this is to store the value of a number
		char value[50];
		//_itoa converts the integer to a string and copiesd that value into the 2nd parameter, the 3rd parameter is the number base
		_itoa((int)numbCarsSoldPerReceiptHistoryList[lineNumber], value, 10);
		//then copy value into line
		strcpy(line, value);

		//then I append a comma to separate the data.
		strcat(line, ",");
		//repeat for every data type i am outputing to the file.
		_itoa((int)typeOfCarSoldPerReceiptHistoryList[lineNumber], value, 10);
		//then copy value into line
		strcat(line, value);
		strcat(line, ",");
		_itoa((int)wasDiscountGivePerReceiptHistoryList[lineNumber], value, 10);
		//then copy value into line
		strcat(line, value);
		strcat(line, ",");
		//then will copy the age into the file
		//this makes the flaot age variable into a string and copies that into value. also has a maxiumum of 50 charaters
		snprintf(value, 50, "%f", customerAgeHistoryList[lineNumber]);
		strcat(line, value);
		strcat(line, ",");

		//then i will append the user name into the the line
		strcat(line, userNameHistoryList[lineNumber]);

		//if this is not the end of the file, append a \n to the end of the line
		if (lineNumber != (numberOfReceipts - 1)) {
			strcat(line, "\n");
		}

		//then output the line into the file.
		fprintf(file, line);
	}




}

void outputDataToFile(char* fileName) {
	//this function outputs data to file.
	//this opens the file and checks if a file is opened or not. and outputs errors based on the result.
	openFile(fileName, "w");
	//this 
	switch (fileState) {
		case FILE_OPENED:
			//if file is opened then write data from file
			writeDataToFile();
			break;
		case FILE_ERROR:
			//if error occured, display error message to user and the quit the program.
			displayFileError();
			break;
	}
	//after this i will attempt to close the file, if the file open. the function does nothing if the file is not open though.
	closeFile();


}

void menu_greetUser() {
	//these lienes greet the user
	printf("Hello Possible Customer to Car Sale Inc. \n");
}

void menu_displayMenu() {
	//now menu time. this bit outputs the menut
	printf("Menu\n");
	printf("Please type in 1 of the following letters to do the corrosponding action:\n");
	printf("\t%c: View Car types Stats.\n", MENU_VIEW_CAR_TYPES_OPTION);
	printf("\t%c Buy cars.\n", MENU_BUY_CARS_OPTION);
	printf("\t%c: View Sales Stats.\n", MENU_VIEW_SALES_INFO_OPTION);
	printf("\t%c: Exit.\n\n", MENU_EXIT_OPTION);

	//this gets the answer bit
	printf("Answer: ");
}

char menu_getUserMenuInput() {
	//this gets the users reponce for the menu
	char userBufferInput[4];

	//store the users input in a string
	getStringInput(userBufferInput, 4);

	//if the length of the input is equal to 1, then return the charater. 
	if (strlen(userBufferInput) == 1) {
		return userBufferInput[0];
	}
	//otherwise, return the null charater, which will cause the default option to occur
	return '\n';
}

void getCustomerName() {
	//Then I will first get the users name
	printf("What is your first name. Answer: ");
	
	char nameBuffer[MAX_NAME_LENGTH];
	//then i record the name to the history lists.
	getStringInput(nameBuffer, MAX_NAME_LENGTH);
	
	//then record the name of the person
	strcpy(userNameHistoryList[numberOfReceipts] , nameBuffer);

	//then i will greet the person.
	printf("Hello %s.\n", userNameHistoryList[numberOfReceipts]);

}

void displayCarType_outputCarTypesByAmmountRemaining(int amountOfCarTypes) {
	//this will output the car types and the amount left in descending order
	//cuurentCarType is a variable there for readability
	int currentCarType;

	for (int carType = 0; carType < amountOfCarTypes; carType++) {
		currentCarType = arrayOfCarTypePointers[carType];
		//currentCarType is the index position of the car type with the largest amount of cars remaining, and then the next carr type with the
		//2nd most of cars remaining on and on until you get the index position of the car type with the fewest amount of cars left.
		//also price is outputed with 2 decimal places.
		printf("Name of Car: %s | Price of Car: %.2f GBP | Amount Of Cars left: %d\n", nameOfCarType[currentCarType], 
			convertPenceToPounds((long)priceOfCarType[currentCarType]), amountOfEachCarTypeLeftList[currentCarType]);
	}

}

void menu_displayCarTypeStats() {
	//this displays the car types in decending order of amount left
	// 
	//first I need to find the number of items in the carType arrays.
	int numberOfCarTypes = getNumberOfCarTypes();
	
	//then I will sort the array. the array itself is an int type, but if i temporarily change the data type of the ointer to a long pointer
	//then i will sort the array without perminantly changing the addresses of the amountOfEachCarTypeLeftList array. so I am generalizing the
	//bubble sort.
	bubbleSortLongValues((long*)amountOfEachCarTypeLeftList, arrayOfCarTypePointers, numberOfCarTypes, 'd');

	//then I will output the car types with the amount of cars left in descending order.
	displayCarType_outputCarTypesByAmmountRemaining(numberOfCarTypes);
	//displayCarType_outputCarTypesByAmmountRemaining(numberOfCarTypes);
	// 
	//finally I will resort the index list, just in case i need to use it latter.
	cleanUpPointerArray(arrayOfCarTypePointers, numberOfCarTypes);

}

void buyCars_displayCarInfo(unsigned int numberOfCarTypes) {
	//here i will output the number of cars left, the car index(basically number the car type), price,
	//and the name of the car

	for (unsigned int carIndex = 0; carIndex < numberOfCarTypes; carIndex++) {
		//the lines below make it so if there are no cars of a particular type left, the information about
		//the cars is not displayed
		if (amountOfEachCarTypeLeftList[carIndex] > 0) {
			printf("%d - %s. Price: :%.2f GBP Amount left: %d\n", carIndex, nameOfCarType[carIndex], 
				convertPenceToPounds((long)priceOfCarType[carIndex]), amountOfEachCarTypeLeftList[carIndex]);
		}
		//find way to print cars with quantitys >0
	}


	//then i will ask them to pick 1 of the following
	printf("\n\nPlease pick 1 of the above car numbers. Answer: ");


}

int buyCars_getCustomerCarTypeChoice(int numberOfCarTypes) {
	//this gets the type of car the user will buy
	
	int isInputValueAnInteger = FALSE;

	//the user choice is here
	int userCarTypeChoice;

	//used to check if value is an integer or not.
	char userCarTypeChoiceBuffer[50];
	//this is used to keep the loop going until the user gives a good answer
	unsigned short isUserCarTypeChoiceTrue = FALSE;

	do {
		//then we check input the value as a string
		getStringInput(userCarTypeChoiceBuffer, 50);
		//then we check if the inputed value is a number or not 
		isInputValueAnInteger = checkIfValueIsAnIntegral(userCarTypeChoiceBuffer, DATA_TYPE_SIGNED_INT_INDEX);
		if (isInputValueAnInteger == TRUE) {
			//if the input is a number, then convert the string back to an integer
			userCarTypeChoice=getIntegerInput(userCarTypeChoiceBuffer);

			//this checks if there are cars in stock, or in other words, if the option is available.
			//this checks if the customers choice was an acceptable number, i.e. If i offer option 1,2,3,4, they choice option 5, which 
			//would cause an error, so i stoped that.
			if (userCarTypeChoice >= 0 && userCarTypeChoice < numberOfCarTypes) {
				//its userCarChoice < numberOfCarTypes not <= since numberOfCarTypes starts at 1, while the chpice starts at 0.
				//preventing an off by 1 error
				
				//I then checking if there are any of the users selected car types left in stock. 
				if (amountOfEachCarTypeLeftList[userCarTypeChoice] > 0) {
					//I first checked if the user input was acceptable before checking if that car was in stock since otherwise if I first
					//checked if the car was in stock and then checked if the user input was within the acceptable range, Then they could
					//have chosen option 2^16+1, or some pother number which would be biiger than the max size of the array, causing an error


					//then I tell program to exit the loop.
					isUserCarTypeChoiceTrue = TRUE;
					typeOfCarSoldPerReceiptHistoryList[numberOfReceipts] = userCarTypeChoice;
					//then i assign to the history list the type of car sold.

				}
				else {
					//if there are no cars of that type avaialble, then reject that answer and try again.
					printf("\nSorry, we are out of stock of the selected car. Please try again.\n");
				}
			}
			else {
				//if the user gave a too big number for car types
				printf("Value entered was not 1 of the selectable values. Please try again.\n");
			}
		
		
		
		}
		//scanf("\n%d", &userCarTypeChoice);
		



	} while (isUserCarTypeChoiceTrue == FALSE);
	
	//then I return the result to the user
	return userCarTypeChoice;
}

unsigned short buyCars_getNumberOfCarsToBuy(int userCarTypeChoice) {
	//this finds out how many cars the user wants to buy
	// 
	//this is how many care the user want to buy
	unsigned short numCarsToBuy;

	//this is a variable to act as a placeholder for the value until checks have been done on the variable that make sure it can be stored as a number.
	char numCarsToBuyBuffer[9];

	int isInputValueAnUnsignedShort = FALSE;

	//this is the condition needed for the loop to stop
	unsigned short isNumCarsBuyTrue = FALSE;
	do {
		//these lines Ask how many cars they want to purchase and Allow the user to enter the number of cars they want
		printf("How many %s cars do you want to purchase? Answer: ", nameOfCarType[userCarTypeChoice]);


		
		getStringInput(numCarsToBuyBuffer, 9);
		isInputValueAnUnsignedShort = checkIfValueIsAnIntegral(numCarsToBuyBuffer, DATA_TYPE_UNSIGNED_SHORT_INDEX);

		if (isInputValueAnUnsignedShort == TRUE) {
			//then we get the error checking
			numCarsToBuy = getUnsignedShortInput(numCarsToBuyBuffer);
			if (numCarsToBuy <= (unsigned short)amountOfEachCarTypeLeftList[userCarTypeChoice] && numCarsToBuy > 0) {
				printf("Thank you for your input \n");
				isNumCarsBuyTrue = TRUE;
				numbCarsSoldPerReceiptHistoryList[numberOfReceipts] = numCarsToBuy;
				amountOfEachCarTypeLeftList[userCarTypeChoice] -= (int)numCarsToBuy;
				//if input is acceptable, leave the loop, else, tell user to behave.
			}
			else if (numCarsToBuy > amountOfEachCarTypeLeftList[userCarTypeChoice]) {
				//glich here that makes strings allow to enter here, since strings are treated as numbers here.
				printf("The amount is greater than the number of avaiable cars, so please try again. Answer: \n");
			}
			else if (numCarsToBuy <= 0) {
				printf("Please enter a positive value for amountt of cars to purchase. Answer: \n");
				//this shouldn't occur, since the numCarsToBuy is a unsigned variable, and hence should never be negative, but just in cased the user is somehow
				//able to do it, then this will catch them out
			}
		
		
		}

	} while (isNumCarsBuyTrue == FALSE);
	//if the user escapes the while loop, then they gave a correct input.

	return numCarsToBuy;

}

float buyCars_getUserAge(float userAge) {
	//this gets the users age

	unsigned short isUserAgeValid = FALSE;
	char userAgeBuffer[50];

	int isUserAgeAFloat;
	//ask user for their age
	printf("We want to apply a discount based on your age. How old are you in years? Answer:");
	do {

		getStringInput(userAgeBuffer, 50);
		isUserAgeAFloat = checkIfNumberIsNumber(userAgeBuffer,DATA_TYPE_FLOAT_INDEX);
		if (isUserAgeAFloat == TRUE) {
			userAge = getFloatInput(userAgeBuffer);
			if (userAge > 0) {
				//this checks if the users age is above 0 years old. if so, great, continue on like normal, otherwise try again.
				customerAgeHistoryList[numberOfReceipts] = userAge;
				isUserAgeValid = TRUE;

			}
			else {
				//user gave a non valid age, so ask them to try again
				printf("User must be alive, so please enter a positive value for your age. Answer:");
			}
		}
		else {
			printf("value was not a number. please try again. Answer: ");
		}
	

	} while (isUserAgeValid == FALSE);

	return userAge;
}

unsigned short buyCars_checkIfDiscountGiven(float userAge) {
	//this decides if a discount is given

	unsigned short applyDiscountState = FALSE;

	if (userAge >= MINIMUM_DISCOUNT_AGE && userAge <= MAXIMUM_DISCOUNT_AGE) {
		printf("You get a discount for %d %% \n", (int)(100 * (CAR_DISCOUNT_AMOUNT)));
		//this will tell code to apply a discount.
		applyDiscountState = TRUE;
	}
	else if (userAge < MINIMUM_DISCOUNT_AGE || userAge > MAXIMUM_DISCOUNT_AGE) {
		printf("You do not get a discount. We are deeply sorry for your loss.");
		//we shouldn't put a return statement because that is an expected result. its ok not to get an discount. and of course we will totally trust the usser to tell their age honestly.
		applyDiscountState = FALSE;
		//saying its false, because otherwise if 1 person got a discount and the next person was not in discount range, they would get the
		//discount anyway due to not resetting the discount state.
	}

	//then i will record if the user got a discount.
	wasDiscountGivePerReceiptHistoryList[numberOfReceipts] = applyDiscountState;

	return applyDiscountState;
}

void buyCars_displayFinalCarPrice(long totalCost, int userCarTypeChoice) {
	//this displays the total cost to the user
	printf("It will cost you %.2f GBP.\n", convertPenceToPounds(totalCost));

	//then I output to the user how many car type n are left.
	printf("There are now %d %s cars Left.\n", amountOfEachCarTypeLeftList[userCarTypeChoice], nameOfCarType[userCarTypeChoice]);

	
}

void buyCars_calculateCarPrice(int userCarTypeChoice, unsigned short applyDiscountState, unsigned short numCarsToBuy) {
	//this calculates the price of the cars

	//when i add iteration statements, i will need to reest total cost at repeat runs. So futureprofffing
	long totalCost = (long)numCarsToBuy * (long)priceOfCarType[userCarTypeChoice];

	//totalCost = (long)numCarsToBuy * (long)priceOfCarType[userCarTypeChoice];
	//not to self, update this latter sinc eusing userCarTypeChoice which may not be the same.

	if (applyDiscountState == TRUE) {
		//this bit applies the discount
		//note, we have reduced the totalCost by a percentage, and since the total cost is a long variable, we may loose data, ie the decimal points. however better storing
		//money as a integer than a float since floats become less precise the bigger the number is, and may loose data that way.  
		totalCost *= (1 - CAR_DISCOUNT_AMOUNT);
	}


	//then i will display the final cost to the user
	buyCars_displayFinalCarPrice(totalCost, userCarTypeChoice);

	//then will record prices
	amountOfMoneyGainedPerPurchaseArray[numberOfReceipts] = totalCost;
	//then i will record amount of money saved by discount, since you want to to explicityly record the values
	discountValuePerPurchaseArray[numberOfReceipts] = ((long)numCarsToBuy * (long)priceOfCarType[userCarTypeChoice]) - totalCost;
}

unsigned int findNumberOfAvailableCars(int numberOfCarTypes) {
	//this finds the number of available cars.
	unsigned int numberOfAvailableCars = 0;

	for (int amountOfCarTypeInStock = 0; amountOfCarTypeInStock < numberOfCarTypes; amountOfCarTypeInStock++) {
		numberOfAvailableCars += amountOfEachCarTypeLeftList[amountOfCarTypeInStock];
		//the program currently doesn't know how many cars there are. it only knows the amount of a specific type of car. eg it knows there are 5 toyotas,
		//and 3 lamberginees, but it doesn't know that there are 8 cars total. this loop tries to get that information.
		// It is achieved by adding every individual car total to get 1 value
	}
	return numberOfAvailableCars;
}

void menu_buyCars() {
	//this buys cars

	int numberOfCarTypes = getNumberOfCarTypes();
	//this finds the number of available cars
	int numberOfAvailableCars = findNumberOfAvailableCars(numberOfCarTypes);

	//used to find what type of car the user wants to buy
	int userCarTypeChoice;

	//this is how many care the user want to buy
	unsigned short numCarsToBuy;

	//this is how long the user has lived in ther life
	float userAge=0;

	unsigned short applyDiscountState = FALSE;
	//very first, checking if there i any avaliable cars left to buy, if not stop this.
	if (numberOfAvailableCars == 0) {
		printf("Sorry, we are out of stock. We thank you for your purchase.\n");
		return;
	}

	//Then I will first get the users name
	getCustomerName();

	//here i will output the number of cars left, the car index, price,and the name of the car
	buyCars_displayCarInfo(numberOfCarTypes);

	userCarTypeChoice = buyCars_getCustomerCarTypeChoice(numberOfCarTypes);

	//must error check it latter.

	//this clears the screen of error messages. this will improve the user experience
	clearScreen();

	numCarsToBuy = buyCars_getNumberOfCarsToBuy(userCarTypeChoice);

	//now trying to apply the discount. to do this i will need the users age
	userAge = buyCars_getUserAge(userAge);



	//should check if userage is an integer latter on.

	//this bit of code checks if the user will get a discount or not
	applyDiscountState = buyCars_checkIfDiscountGiven(userAge);
	//This calculates the price of how many cars the user wants to buy

	//now i will output the price to the user.
	//fist i will calc the price. 
	buyCars_calculateCarPrice(userCarTypeChoice, applyDiscountState, numCarsToBuy);


	//this is to make sure that i update the next purchase history stuff correctly.
	//need to update the array the records what pruchase occured
	customerPurchaseHistoryPointerArray[numberOfReceipts] = numberOfReceipts;
	numberOfReceipts += 1;




}

void viewSales_displaySumeryInfo(unsigned int numberOfCarsSold, long totalMoneyGained) {
	//this displays the summery stats of the car sales overall
	printf("\n\n Summery Sales Statistics:\n");
	printf("Total number of available Cars = %d \n", (MAX_RECEIPTS - numberOfCarsSold));
	printf("total number of cars sold = %d \n", numberOfCarsSold);
	printf("Total number of Money gained = %.2f GBP \n", convertPenceToPounds(totalMoneyGained));
}

void viewSales_displayIndividualPurchaseInfo(unsigned int currentReceiptIndex, long priceOfCars, unsigned int typeOfCarIndex,
	char displayHasDiscount[4],long discountValue) {
	//this dipslays the information about an individual purchases
	printf("Receipt number: %d | Customer Name: %s | Customer Age:%f Years| Type Of Car: %s | Number of Cars Sold: %hd | Amount Of Money Gained: %.2f GBP | "
		"Was Discount Given: %s | Discount Value %.2f GBP\n", currentReceiptIndex, userNameHistoryList[currentReceiptIndex],
		customerAgeHistoryList[currentReceiptIndex], nameOfCarType[typeOfCarIndex], numbCarsSoldPerReceiptHistoryList[currentReceiptIndex], 
		convertPenceToPounds(priceOfCars), displayHasDiscount, convertPenceToPounds(discountValue));
	


}

void viewSales_OutputIndividualPurchaseInfoAndDeriveMacroscopicViewSalesValues(long* totalMoneyGained,unsigned int* numberOfCarsSold,
	long* totalMoneyGainedPerCarTypeArray) {
	//this function outputs the sales info about each purchase the occured, and passes by reference the macroscopic values to the view sales function

	//records price of purchase, and the amount of money saved by a discount which will equal 0 if no discount was given.
	long priceOfCars, discountValueOfPurchase;
	//this index refurs to the type of car specified.
	unsigned int typeOfCarIndex;
	//used to output either yes or no to wether a discount was given or not
	char displayHasDiscount[4];

	printf("Individial Sales:\n");
	//this bit outputs every pruchase that happened.
	for (unsigned int currentReceiptIndex = 0; currentReceiptIndex < numberOfReceipts; currentReceiptIndex++) {
		//this for loop figures out the individual sales stats and then outputs them. I can't put this as a separite function because the other
		//function about outputing sales stats requires 2 parameters of different data types, both found in this for loop. A function can only 
		//return 1 output, so if this is a sparite function, then the display sumery info function will not work.

		//reseting this info at the begining


		//this finds the type of car index which is there for readability
		typeOfCarIndex = typeOfCarSoldPerReceiptHistoryList[currentReceiptIndex];

		//finding the price of the purchase and the discount value
		priceOfCars = amountOfMoneyGainedPerPurchaseArray[currentReceiptIndex];
		discountValueOfPurchase = discountValuePerPurchaseArray[currentReceiptIndex];

		//checking if discount was given, to decide what to output to the user.
		if (wasDiscountGivePerReceiptHistoryList[currentReceiptIndex] == TRUE) {
			strcpy(displayHasDiscount, "Yes");
		}
		else {
			strcpy(displayHasDiscount, "No");
		}

		//then display the pruchase to the user.
		viewSales_displayIndividualPurchaseInfo(currentReceiptIndex, priceOfCars, typeOfCarIndex, displayHasDiscount, discountValueOfPurchase);

		//this will be used for sumery data
		*totalMoneyGained += priceOfCars;
		//this records the amount of money gained for a particular car type. 
		totalMoneyGainedPerCarTypeArray[typeOfCarIndex] += priceOfCars;
		*numberOfCarsSold += numbCarsSoldPerReceiptHistoryList[currentReceiptIndex];
	}


}

void viewSales_outputCarTypeInfo_displayCarTypeInfo(int amountOfCarTypes, long* totalMoneyGainedPerCarTypeArray) {
	//this outputs the car type info in order of sales
	
	//cuuentCarType is a variable there for readability
	int currentCarType;

	for (int carType = 0; carType < amountOfCarTypes; carType++) {
		currentCarType = arrayOfCarTypePointers[carType];
		//currentCarType is the index position of the car type with the largest amount of cars remaining, and then the next carr type with the
		//2nd most of cars remaining on and on until you get the index position of the car type with the fewest amount of cars left.
		//also price is outputed with 2 decimal places.

		//broke the printf() command into multiple lines for readability.
		printf("Name of Car: %s | Price of Car: %.2f GBP | Amount Of Cars left: %d | Amount Of money Gained For %s: %.2f GBP\n",
			nameOfCarType[currentCarType], convertPenceToPounds((long)priceOfCarType[currentCarType]),
			amountOfEachCarTypeLeftList[currentCarType], nameOfCarType[currentCarType],
			convertPenceToPounds(totalMoneyGainedPerCarTypeArray[currentCarType]));
	}
}

void viewSales_outputCarTypeSalesInfo(long* totalMoneyGainedPerCarTypeArray) {
	//this outputs info about the car types, to acheive the objective below.
	//Sales figures are displayed as a total sum for each Car model, Sorted by total sale amount in descending order
	
	printf("\n\n Summery Car Type Sales Info \n");

	//first find number of car types.
	int numberOfCarTypes = getNumberOfCarTypes();
	
	//then i need to sort the array by total sale amount.
	bubbleSortLongValues(totalMoneyGainedPerCarTypeArray, arrayOfCarTypePointers, numberOfCarTypes, 'd');

	//this actually displays to the console the car type info
	viewSales_outputCarTypeInfo_displayCarTypeInfo(numberOfCarTypes, totalMoneyGainedPerCarTypeArray);

	//then i will clean up the pointer array.
	cleanUpPointerArray(arrayOfCarTypePointers, numberOfCarTypes);
}

void menu_viewSalesMenu() {
	//this bit tells the user about the sales info 
	//records number of cars sold
	unsigned int numberOfCarsSold = 0;
	//records total money gained
	long totalMoneyGained = 0;
	//this is an array that holds the amount of money gained per car type.
	long totalMoneyGainedPerCarTypeArray[] = { 0, 0, 0, 0 };

	//output sales information
	printf("\n\nSales information.\n\n");

	//records price of purchase, and the amount of money saved by a discount, 0 if no discount was given.
	viewSales_OutputIndividualPurchaseInfoAndDeriveMacroscopicViewSalesValues(&totalMoneyGained, &numberOfCarsSold,
		totalMoneyGainedPerCarTypeArray);

	//this outputs the car info about each individual car type
	viewSales_outputCarTypeSalesInfo(totalMoneyGainedPerCarTypeArray);

	//this displays the summery info of cars sold.
	viewSales_displaySumeryInfo(numberOfCarsSold, totalMoneyGained);

}

void menu_exitMenu() {
	//exit statement to thank user for saying not to buy stuff
	printf("Thank you for considering to buy stuff from Car Sale Inc.\n");
}

void main() {
	//first great the user
	menu_greetUser();
	getDataFromFile(currentFileName);
	//this is used to store the users menu choice.
	char userMenuChoice;
	do {


		//outputs menu
		menu_displayMenu();

		userMenuChoice = menu_getUserMenuInput();

		//this clears the console, which increases readalility
		clearScreen();

		//using a switch statement here since there are more than 3 atempts to check if a value equals an option
		//also this bit decides what menu option but the program executes.
		switch (userMenuChoice) {
			case MENU_VIEW_CAR_TYPES_OPTION:
				//this option allows the customer to view the data about the car types.
				menu_displayCarTypeStats();
				break;

			case MENU_BUY_CARS_OPTION:
				//this option allows customer to buy cars
				menu_buyCars();
				break;

			case MENU_VIEW_SALES_INFO_OPTION:
				//this bit tells the user about the sales info 
				menu_viewSalesMenu();
				break;

			case MENU_EXIT_OPTION:
				//exit statement to thank user for saying not to buy stuff
				menu_exitMenu();
				break;

			default:
				//this is the bad data responce. 
				printf("Please enter a valid input, either a,b or c please.");
				break;
		}


		pauseProgram(userMenuChoice, FALSE);

		//this clears the console, which increases readalility
		clearScreen();
	} while (userMenuChoice != MENU_EXIT_OPTION);

	outputDataToFile(currentFileName);

	printf("Have a nice day.");
}
